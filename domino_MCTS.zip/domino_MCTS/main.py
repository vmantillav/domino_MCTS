import numpy as np
from IPython import get_ipython
from simulation import simulate_game

def clear_console():
    try:
        get_ipython().magic('clear')
    except:
        pass

simulate_game(player_strat="human",pc_strat="MCTS",iterations=10000,c=9)
