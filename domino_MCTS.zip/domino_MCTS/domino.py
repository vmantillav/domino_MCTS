import numpy as np
from copy import deepcopy as dc

#domino game simulation functions
def add_tile(tile,U,side=None):
  if len(U)==0:
    U.append(tile)
  elif side=="left":
    lv=get_left_value(tile)
    rv=get_right_value(tile)
    ti=get_tile_index(tile)
    for i in range(len(U)):
      cln=get_left_neighbour(U[i])
      cti=get_tile_index(U[i])
      if cln==0:
        clv=get_left_value(U[i])
        if clv==lv:
          U[i]=set_left_neighbour(U[i],ti)
          tile=set_right_neighbour(tile,cti)
          tile=turn_tile(tile)
          U.append(tile)
          break
        if clv==rv:
          U[i]=set_left_neighbour(U[i],ti)
          tile=set_right_neighbour(tile,cti)
          U.append(tile)
          break
  elif side=="right":
    lv=get_left_value(tile)
    rv=get_right_value(tile)
    ti=get_tile_index(tile)
    for i in range(len(U)):
      crn=get_right_neighbour(U[i])
      cti=get_tile_index(U[i])
      if crn==0:
        crv=get_right_value(U[i])
        if crv==rv:
          U[i]=set_right_neighbour(U[i],ti)
          tile=set_left_neighbour(tile,cti)
          tile=turn_tile(tile)
          U.append(tile)
          break
        if crv==lv:
          U[i]=set_right_neighbour(U[i],ti)
          tile=set_left_neighbour(tile,cti)
          U.append(tile)
          break
  else:
    prev=len(U)
    lv=get_left_value(tile)
    rv=get_right_value(tile)
    ti=get_tile_index(tile)
    for i in range(len(U)):
      cln=get_left_neighbour(U[i])
      crn=get_right_neighbour(U[i])
      cti=get_tile_index(U[i])
      if cln==0:
        clv=get_left_value(U[i])
        if clv==lv:
          U[i]=set_left_neighbour(U[i],ti)
          tile=set_right_neighbour(tile,cti)
          tile=turn_tile(tile)
          U.append(tile)
          break
        elif clv==rv:
          U[i]=set_left_neighbour(U[i],ti)
          tile=set_right_neighbour(tile,cti)
          U.append(tile)
          break
      if crn==0:
        crv=get_right_value(U[i])
        if crv==rv:
          U[i]=set_right_neighbour(U[i],ti)
          tile=set_left_neighbour(tile,cti)
          tile=turn_tile(tile)
          U.append(tile)
          break
        if crv==lv:
          U[i]=set_right_neighbour(U[i],ti)
          tile=set_left_neighbour(tile,cti)
          U.append(tile)
          break
    if(prev==len(U)):
      print("Error in add_tiles!")
      print(U)
  return U

def all_tiles():#Tile structure: index,turned (0:not turned),left neighbour,right neighbour,value1,value2
  array=[]
  for i in range(28):
    if i<7:
      tile=[i+1,0,0,6,i]
    elif i<13:
      tile=[i+1,0,0,5,i%7]
    elif i<18:
      tile=[i+1,0,0,4,i%13]
    elif i<22:
      tile=[i+1,0,0,3,i%18]
    elif i<25:
      tile=[i+1,0,0,2,i%22]
    elif i<27:
      tile=[i+1,0,0,1,i%25]
    else:
      tile=[i+1,0,0,0,0]
    array.append(tile)
  return array

def ask_for_move(limit):
  move=0
  while move==0:
    print("Please select a tile to play:")
    cand=int(input())
    if cand>0 and cand<=limit:
      move=cand
    else:
      print("Invalid tile.")
  print("")
  return move-1

def ask_for_side(extremes):
  side=-1
  while side<0:
    print("Please choose a side to play:")
    print("Left extreme ("+str(extremes[0])+") write 1.")
    print("Right extreme ("+str(extremes[1])+") write 2.")
    cand=int(input())
    if cand==1 or cand==2:
      side=cand
    else:
      print("Invalid side.")
  print("")
  return side-1

def put_tile(tile,U,extremes,strat="random"):
  left_value=get_left_value(tile)
  right_value=get_right_value(tile)
  if (left_value==extremes[0] and right_value==extremes[1]) or (left_value==extremes[1] and right_value==extremes[0]):
    if strat=="random":
        side=np.random.randint(2)
    elif strat=="human":
        side=ask_for_side(extremes)
    if side==0:
        U=add_tile(tile,U,"left")
    elif side==1:
        U=add_tile(tile,U,"right")
  else:
    U=add_tile(tile,U)
  return U

def extreme_tiles_numbers(U):
  extremes=[-1,-1]
  for tile in U:
    if get_left_neighbour(tile)==0:
      extremes[0]=get_left_value(tile)
    if get_right_neighbour(tile)==0:
      extremes[1]=get_right_value(tile)
  if extremes[0]>=0 and extremes[1]>=0:
    return extremes
  else:
    print("Error in extremes!")
    print(U)

def get_left_neighbour(tile):
  return tile[1]

def get_left_value(tile):
  return tile[3]

def get_right_neighbour(tile):
  return tile[2]

def get_right_value(tile):
  return tile[4]

def get_tile_index(tile):
  return tile[0]

def get_tiles(tiles,amount):
  mix_tiles(tiles)
  l=len(tiles)
  if l>=amount:
    extracted=[]
    for i in range(amount):
      tile=tiles[np.random.randint(l-i)]
      tiles.remove(tile)
      extracted.append(tile)
    return extracted,tiles

def graph_current_game(U):
  copy=U.copy()
  if len(copy)==1:
    text="|"+str(get_left_value(copy[0]))+":"+str(get_right_value(copy[0]))+"|"
  elif len(U)>1:
    left_extreme=0
    arranged_tiles=[]
    text=""
    while len(copy)>0:
      for tile in copy:
        cln=get_left_neighbour(tile)
        if cln==left_extreme:
          arranged_tiles.append(tile)
          copy.remove(tile)
          left_extreme=get_tile_index(tile)
          break
    for tile in arranged_tiles:
      text+="|"+str(get_left_value(tile))+":"+str(get_right_value(tile))+"|"
  print(text)
  print("")

def graph_tiles(P,limit=0):
  text=""
  for i in range(len(P)):
    text+="|"+str(get_left_value(P[i]))+"|"
  text+="\n"
  for i in range(len(P)):
    text+="|"+str(get_right_value(P[i]))+"|"
  text+="\n"
  for i in range(limit):
    text+=" "+str(i+1)+" "
  print(text)
  print("")

def mix_tiles(tiles):
  return np.random.shuffle(tiles)

def playable_tiles(P,extremes):
  limit=0
  arranged_tiles=[]
  change=True
  while change:
    change=False
    for tile in P:
      left_value=get_left_value(tile)
      right_value=get_right_value(tile)
      if left_value in extremes or right_value in extremes:
        arranged_tiles.append(tile)
        P.remove(tile)
        change=True
        limit+=1
        break
  for tile in P:
    arranged_tiles.append(tile)
  return limit, arranged_tiles

def set_left_neighbour(tile, index):
  tile[1]=index
  return tile

def set_right_neighbour(tile,index):
  tile[2]=index
  return tile

def start_game():
  S=all_tiles()
  P,S=get_tiles(S,7)
  C,S=get_tiles(S,7)
  return P,C,S

def sum_tile_values(P):
  summ=0
  for tile in P:
    summ+=get_left_value(tile)+get_right_value(tile)
  return summ

def turn_tile(tile):
  aux=tile[3]
  tile[3]=tile[4]
  tile[4]=aux
  return tile

def get_UPS(U,P,S):
    UPS=[]
    extremes=extreme_tiles_numbers(U)
    limit,P=playable_tiles(P,extremes)
    if limit==0:
        if len(S)>0:
            for s in S:
                NU=dc(U)
                NP=dc(P)
                NS=dc(S)
                NS.remove(s)
                NP.append(s)
                UPS.append([NU,NP,NS])
            return True,UPS
        else:
            UPS=None
    else:
        for l in range(limit):
            NU=dc(U)
            NP=dc(P)
            NS=dc(S)
            NU=put_tile(NP[l],NU,extremes)
            NP.remove(NP[l])
            UPS.append([NU,NP,NS])
        return False,UPS