import numpy as np
from tqdm import tqdm
import multiprocessing
from IPython import get_ipython
from datetime import datetime as dt
from joblib import Parallel, delayed
from simulation import simulate_game
import matplotlib.pyplot as plt

def clear_console():
    try:
        get_ipython().magic('clear')
    except:
        pass
    
def simulate_game_multiprocess(iterations,c,games,njobs=-1):
    num_cores = multiprocessing.cpu_count()
    if njobs>0 and njobs<num_cores:
        num_cores=njobs
    if __name__ == "__main__":
        outputs = Parallel(n_jobs=num_cores)(delayed(simulate_game)(pc_strat="MCTS",iterations=iterations,c=c) for _ in range(games))
        return outputs

source="experiments.txt"
"""
iterations=10000
c=9
games=100
while True:
    now=dt.now()
    scores=simulate_game_multiprocess(iterations,c,games)
    score=np.mean(scores)
    std=np.std(scores)
    now=dt.now()-now
    print(c,score,std,now)
    f=open(source,"a+")
    f.write(str(iterations)+";"+str(c)+";"+str(games)+";"+str(score)+";"+str(std)+";"+str(now.total_seconds())+"\n")
    f.close()

lines=open(source,"r").read().split("\n")
while len(lines[-1])==0:
    lines=lines[:-1]
values=np.asarray([[float(item) for item in line.split(";")] for line in lines])
plt.hist(values[:,2])
"""
clear_console()

source="c_score.txt"
iterations=100
games=1000
prev_score=0
curr_score=-1
for c in range(20):
    now=dt.now()
    scores=simulate_game_multiprocess(iterations,c,games)
    score=np.mean(scores)
    std=np.std(scores)
    now=dt.now()-now
    print(c,score,std,now)
    f=open(source,"a+")
    f.write(str(iterations)+";"+str(c)+";"+str(games)+";"+str(score)+";"+str(std)+";"+str(now.total_seconds()/games)+"\n")
    f.close()



    

            