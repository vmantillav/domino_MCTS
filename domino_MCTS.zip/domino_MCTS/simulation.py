import sys
import numpy as np
from copy import deepcopy as dc
from datetime import datetime as dt
from anytree import Node, RenderTree, AsciiStyle, LevelOrderIter
from domino import (start_game,
                    extreme_tiles_numbers,
                    playable_tiles,
                    put_tile,
                    get_tiles,
                    get_UPS,
                    sum_tile_values,
                    graph_tiles,
                    graph_current_game,
                    ask_for_move)

def simulate_game(U=[],P=[],C=[],S=[],T=False,R=True,player_strat="random",pc_strat="random",iterations=1000,c=2,graph=False):
    if len(U)==0 and len(P)==0 and len(C)==0 and len(S)==0:
        U=[]
        P=[]
        C=[]
        S=[]
        T=False
        P,C,S=start_game()
        if graph:
            graph_tiles(S)
            graph_tiles(P)
            graph_tiles(C)
    score=-1
    while score==-1:
        if player_strat=="human" and (len(U))>0:
            if R:
                print("Player turn: Current game state")
                print("")
            else:
                print("Computer turn: Thinking...")
                print("")
            graph_current_game(U)
            print("")
            print("Computer tiles left:",len(C))
            print("")
        elif player_strat=="human":
            print("======================================")
            print("")
            print("DOMINO GAME")
            print("")
            print("Current Computer Strategy:",pc_strat)
            print("")
            print("======================================")
            print("")
        aux=None
        if R:
            aux=player_turn(U,P,C,S,strat=player_strat)
            if isinstance(aux,int):
                score=aux
            else:
                U,P,C,S,T=aux
            R=not R
            if graph:
                graph_current_game(U)
                graph_tiles(S)
                graph_tiles(P)
                graph_tiles(C)
        else:
            if player_strat=="human":
                now=dt.now()
            aux=pc_turn(U,P,C,S,T,strat=pc_strat,iterations=iterations,c=c)
            if player_strat=="human":
                print(dt.now()-now)
            if isinstance(aux,int):
                score=aux
            else:
                U,P,C,S=aux
            R=not R
            if graph:
                graph_current_game(U)
                graph_tiles(S)
                graph_tiles(P)
                graph_tiles(C)
    if player_strat=="human" and score==0:
        print("Player wins!")
        print("")
        graph_current_game(U)
    elif player_strat=="human" and score==1:
        print("Computer wins!")
        print()
        graph_current_game(U)
    return score

def random_strategy(U,P,limit,extremes):
    n=np.random.randint(limit)
    U=put_tile(P[n],U,extremes)
    P.remove(P[n])
    return U,P

def max_strategy(U,P,limit,extremes):
    maxx=0
    n=0
    for i in range(len(P[:limit])):
        cand=sum_tile_values([P[i]])
        if cand>maxx:
            maxx=cand
            n=i
    U=put_tile(P[n],U,extremes)
    P.remove(P[n])
    return U,P

def human_strategy(U,P,limit,extremes):
    graph_tiles(P,limit)
    n=ask_for_move(limit)
    if len(U)==0:
        U=[P[n]]
    else:
        U=put_tile(P[n],U,extremes,strat="human")
    P.remove(P[n])
    return U,P
    
def MCTS_strategy(U,P,C,S,iterations=1000,c=2,simulations=10000):
    state={"name":"S-0",
           "U":dc(U),
           "P":dc(P),
           "C":dc(C),
           "S":dc(S),
           "T":False,
           "L":False,
           "R":False,
           "n":0,
           "t":0}
    result=MCTS(state,iterations=iterations,c=c)
    return result.name["U"],result.name["P"],result.name["C"],result.name["S"]

def fixed_strategy(U,P,extremes,n):
    U=put_tile(P[n],U,extremes)
    P.remove(P[n])
    return U,P

def player_turn(U,P,C,S,strat="random"):
    T=False
    if len(U)==0:
        if strat=="random":
            n=np.random.randint(len(P))
            U.append(P[n])
            P.remove(P[n])
            return U,P,C,S,T
        elif strat=="human":
            U,P=human_strategy(U,P,len(P),[])
            return U,P,C,S,T
    else:
        extremes=extreme_tiles_numbers(U)
        limit,P=playable_tiles(P,extremes)
        if limit==0:
            if len(S)>0:
                if strat=="human":
                    print("No valid tiles to play. Taking one from stock...")
                    print("")
                tile,S=get_tiles(S,1)
                limit,tile=playable_tiles(tile,extremes)
                if limit==0:
                    if strat=="human":
                        print("Invalid tile taken from stock. Player must pass.")
                        print("")
                    P.append(tile[0])
                    T=True
                else:
                    if strat=="human":
                        print("Valid tile taken from stock. Playing with it...")
                        print("")
                    U=put_tile(tile[0],U,extremes)
            else:
                T=True
        else:
            if strat=="random":
                U,P=random_strategy(U,P,limit,extremes)
            elif strat=="human":
                U,P=human_strategy(U,P,limit,extremes)
            elif strat=="max":
                U,P=max_strategy(U,P,limit,extremes)
        if len(P)==0:
            return 0
        else:
            return U,P,C,S,T

def pc_turn(U,P,C,S,T,strat="random",iterations=1000,c=2):
    R=False
    extremes=extreme_tiles_numbers(U)
    limit,C=playable_tiles(C,extremes)
    if limit==0:
        if len(S)>0:
            tile,S=get_tiles(S,1)
            limit,tile=playable_tiles(tile,extremes)
            if limit==0:
                C.append(tile[0])
                R=True
            else:
                U=put_tile(tile[0],U,extremes)
        else:
            R=True
    elif limit==1:
        U=put_tile(C[0],U,extremes)
        C.remove(C[0])
    else:
        if strat=="random":
            U,C=random_strategy(U,C,limit,extremes)
        elif strat=="MCTS":
            U,P,C,S=MCTS_strategy(U,P,C,S,iterations=iterations,c=c)
    if len(C)==0:
        return 1
    elif T and R and len(S)==0:
        P_sum=sum_tile_values(P)
        C_sum=sum_tile_values(C)
        if P_sum>C_sum:
            return 1
        else:
            return 0
    else:
        return U,P,C,S

def add_children(parent):
    turn=parent.name["R"]
    name=parent.name["name"]
    first=None
    if turn:
        result=get_UPS(dc(parent.name["U"]),dc(parent.name["P"]),dc(parent.name["S"]))
        if result!=None:
            passed,UPS=result
            index=0
            for ups in UPS:
                data={"name":name+"-"+str(index),
                    "U":ups[0],
                    "P":ups[1],
                    "C":dc(parent.name["C"]),
                    "S":ups[2],
                    "T":passed,
                    "L":False,
                    "R":not turn,
                    "n":0,
                    "t":0}
                if first==None:
                    first=Node(data,parent=parent)
                else:
                    Node(data,parent=parent)
                index+=1
        else:
            parent.name["L"]=True
    else:
        result=get_UPS(dc(parent.name["U"]),dc(parent.name["C"]),dc(parent.name["S"]))
        if result!=None:
            passed,UCS=result
            index=0
            for ucs in UCS:
                data={"name":name+"-"+str(index),
                      "U":ucs[0],
                      "P":dc(parent.name["P"]),
                      "C":ucs[1],
                      "S":ucs[2],
                      "T":False,
                      "L":False,
                      "R":not turn,
                      "n":0,
                      "t":0}
                if first==None:
                    first=Node(data,parent=parent)
                else:
                    Node(data,parent=parent)
                index+=1
        else:
            parent.name["L"]=True
    
def backpropagate(state,value):
  state.name["n"]=state.name["n"]+1
  state.name["t"]=state.name["t"]+value
  while not state.is_root:
    state=state.parent
    state.name["n"]=state.name["n"]+1
    state.name["t"]=state.name["t"]+value

def calculate_ucb1(state,p,c=2):
  n=state.name["n"]
  t=state.name["t"]
  if n==0:
    return sys.maxsize
  else:
    return (t/n)+c*np.sqrt(np.log(p)/n)

def rollout(state,simulations=10000):
    return simulate_game(U=dc(state.name["U"]),
                        P=dc(state.name["P"]),
                        C=dc(state.name["C"]),
                        S=dc(state.name["S"]),
                        T=dc(state.name["R"]),
                        R=dc(state.name["T"]))
  
def get_best_child(parent,end_nodes=True,c=2):
  p=parent.name["n"]
  highest=0
  best_child=None
  for child in LevelOrderIter(parent,maxlevel=2):
    candidate=0
    if child!=parent and (not end_nodes or (end_nodes and not child.name["L"])):
        candidate=calculate_ucb1(child,p,c=c)
    if candidate>highest:
      highest=candidate
      best_child=child
  if best_child==None:
      parent.name["L"]=True
  return best_child

def MCTS(state,iterations=1000,c=2,simulations=10000):
  root = Node(state)
  iters=0
  while iters<iterations and root.name["L"]==False:
    current=root
    iters+=1
    while not current.is_leaf:
      current=get_best_child(current)
      if current==None:
        break
    if current!=None:
      if current.name["n"]==0:
        value=rollout(current,simulations)
        backpropagate(current,value)
      else:
        current=add_children(current)
        if current!=None:
          value=rollout(current,simulations)
          backpropagate(current,value)
  #for pre, _, node in RenderTree(root,maxlevel=2):
    #print("%s%s" % (pre, node.name["name"]+": "+str(node.name["n"])+","+str(node.name["t"])))
  return get_best_child(root,end_nodes=False)